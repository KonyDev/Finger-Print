function AS_Button_a1a3d2fce1e94aaeb272051d46c8b6e0(eventobject) {
    return authUsingTouchID.call(this);
}