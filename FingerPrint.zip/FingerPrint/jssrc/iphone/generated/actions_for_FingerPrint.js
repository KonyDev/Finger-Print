//actions.js file 
function AS_Button_264560fd22464b9d99df49ee7d9d1ff7(eventobject) {
    return isAuthUsingTouchSupported.call(this);
}
function AS_Button_752eaf22690a43438cd2d86d396a4089(eventobject) {
    frmHome.show();
}
function AS_Button_7c6e233cea754abea5815129faed39af(eventobject) {
    frmLogin.show();
}