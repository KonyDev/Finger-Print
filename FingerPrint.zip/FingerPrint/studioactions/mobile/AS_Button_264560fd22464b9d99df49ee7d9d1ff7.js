function AS_Button_264560fd22464b9d99df49ee7d9d1ff7(eventobject) {
    return isAuthUsingTouchSupported.call(this);
}